public enum IndonesianLocalLanguage {
    JAVANESE,
    SUNDANESE
}